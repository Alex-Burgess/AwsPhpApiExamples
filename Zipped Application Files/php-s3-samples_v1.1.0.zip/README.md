# PhpAwsApiExamples
Examples of using the php aws api.
